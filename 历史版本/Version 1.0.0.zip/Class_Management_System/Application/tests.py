from django.test import TestCase

# Create your tests here.

import datetime

print(datetime.date.today())